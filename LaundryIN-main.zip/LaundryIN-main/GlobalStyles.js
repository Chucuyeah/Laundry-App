/* fonts */
export const FontFamily = {
  poppinsExtraBold: "Poppins-ExtraBold",
  poppinsBold: "Poppins-Bold",
};
/* font sizes */
export const FontSize = {
  size_21xl: 40,
};
/* Colors */
export const Color = {
  colorDarkblue: "#11009e",
  colorWhite: "#fff",
};
/* border radiuses */
export const Border = {
  br_11xl: 30,
};
